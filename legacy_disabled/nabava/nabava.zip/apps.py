from django.apps import AppConfig

class NabavaConfig(AppConfig):
    name = 'nabava'
