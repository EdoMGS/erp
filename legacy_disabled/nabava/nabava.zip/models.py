from django.db import models

class PlanNabave(models.Model):
    naziv_projekta = models.CharField(max_length=200)
    artikl = models.CharField(max_length=200)
    kolicina = models.IntegerField()
    datum_potrebe = models.DateField()  # Dodavanje natrag polja datum_potrebe
    status = models.CharField(max_length=100)
    odgovorna_osoba = models.CharField(max_length=200)
    napomena = models.TextField(blank=True, null=True)  # Ostala polja za koja su potrebne promjene

    def __str__(self):
        return f"{self.naziv_projekta} - {self.artikl}"

class ZahtjevZaNabavu(models.Model):
    plan_nabave = models.ForeignKey(PlanNabave, on_delete=models.CASCADE)
    artikl = models.CharField(max_length=200)
    kolicina = models.IntegerField()
    odjel = models.CharField(max_length=200)
    status = models.CharField(max_length=100)
    datum_zahtjeva = models.DateField()

    class Meta:
        app_label = 'nabava'

    def __str__(self):
        return f"Zahtjev za {self.artikl} - {self.status}"

class Dobavljac(models.Model):
    naziv = models.CharField(max_length=200)
    kontakt_osoba = models.CharField(max_length=200)
    adresa = models.CharField(max_length=300)
    ocjena = models.IntegerField()
    pregovarani_uvjeti = models.TextField()

    class Meta:
        app_label = 'nabava'

    def __str__(self):
        return self.naziv

class Narudzba(models.Model):
    STATUSI_NARUDZBE = [
        ('u_pripremi', 'U pripremi'),
        ('poslano', 'Poslano'),
        ('dostavljeno', 'Dostavljeno'),
        ('otkazano', 'Otkazano'),
    ]

    zahtjev_za_nabavu = models.ForeignKey('ZahtjevZaNabavu', on_delete=models.CASCADE)
    dobavljac = models.ForeignKey('Dobavljac', on_delete=models.CASCADE)
    datum_narudzbe = models.DateField(auto_now_add=True)
    datum_dostave = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUSI_NARUDZBE, default='u_pripremi')
    automatski_odobreno = models.BooleanField(default=False)

    class Meta:
        app_label = 'nabava'

    def __str__(self):
        return f"Narudžba {self.id} - {self.dobavljac.naziv}"
