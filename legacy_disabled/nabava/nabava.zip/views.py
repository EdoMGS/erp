
from rest_framework import viewsets
from .models import PlanNabave, ZahtjevZaNabavu, Dobavljac, Narudzba
from .serializers import PlanNabaveSerializer, ZahtjevZaNabavuSerializer, DobavljacSerializer, NarudzbaSerializer

class PlanNabaveViewSet(viewsets.ModelViewSet):
    queryset = PlanNabave.objects.all()
    serializer_class = PlanNabaveSerializer

class ZahtjevZaNabavuViewSet(viewsets.ModelViewSet):
    queryset = ZahtjevZaNabavu.objects.all()
    serializer_class = ZahtjevZaNabavuSerializer

class DobavljacViewSet(viewsets.ModelViewSet):
    queryset = Dobavljac.objects.all()
    serializer_class = DobavljacSerializer

class NarudzbaViewSet(viewsets.ModelViewSet):
    queryset = Narudzba.objects.all()
    serializer_class = NarudzbaSerializer

def nabava_home(request):
    return render(request, 'nabava_home.html')
