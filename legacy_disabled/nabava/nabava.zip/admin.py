from django.contrib import admin
from .models import PlanNabave, ZahtjevZaNabavu, Dobavljac

admin.site.register(PlanNabave)
admin.site.register(ZahtjevZaNabavu)
admin.site.register(Dobavljac)
