# Inventory tracking logic for nabava and skladiste
