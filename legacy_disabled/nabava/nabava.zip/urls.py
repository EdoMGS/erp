
from . import views
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PlanNabaveViewSet, ZahtjevZaNabavuViewSet, DobavljacViewSet, NarudzbaViewSet

router = DefaultRouter()
router.register(r'plan-nabave', PlanNabaveViewSet)
router.register(r'zahtjev-za-nabavu', ZahtjevZaNabavuViewSet)
router.register(r'dobavljaci', DobavljacViewSet)
router.register(r'narudzbe', NarudzbaViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
urlpatterns.append(path('', views.nabava_home, name='nabava_home'))
