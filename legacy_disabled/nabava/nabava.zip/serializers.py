
from rest_framework import serializers
from .models import PlanNabave, ZahtjevZaNabavu, Dobavljac, Narudzba

class PlanNabaveSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanNabave
        fields = '__all__'

class ZahtjevZaNabavuSerializer(serializers.ModelSerializer):
    class Meta:
        model = ZahtjevZaNabavu
        fields = '__all__'

class DobavljacSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dobavljac
        fields = '__all__'

class NarudzbaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Narudzba
        fields = '__all__'
