from django.apps import AppConfig


class FinancijeConfig(AppConfig):
    name = "financije"
