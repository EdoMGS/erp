# Production settings for the Django project


# Add your production-specific settings here
