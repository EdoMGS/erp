from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("tenants", "0003_alter_tenant_domain"),
        ("tenants", "0003_tenantsettings"),
    ]

    operations = []
