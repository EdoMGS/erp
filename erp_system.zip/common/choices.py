from django.utils.translation import gettext_lazy as _

OCJENE_CHOICES = [
    (1, _("Vrlo loše")),
    (2, _("Loše")),
    (3, _("Zadovoljavajuće")),
    (4, _("Dobro")),
    (5, _("Vrlo dobro")),
]
