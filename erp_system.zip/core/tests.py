"""Placeholder core tests module.

Intentionally kept (not removed) because core may later receive unit tests.
Does not define a tests package that conflicts with top-level 'tests' dir
because its module name is 'core.tests', not 'tests'.
"""

# No tests yet.
