"""Stub re-export module: real models defined in prodaja.models to avoid circular imports."""
from prodaja.models import Invoice, InvoiceLine, InvoiceSequence  # noqa:F401


class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, related_name="lines", on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    qty = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('1'))
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0'))  # percent e.g. 25.00
    base_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    tax_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    total_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))

    def save(self, *args, **kwargs):
        self.base_amount = (self.qty * self.unit_price).quantize(Decimal('0.01'))
        self.tax_amount = (self.base_amount * self.tax_rate / Decimal('100')).quantize(Decimal('0.01'))
        self.total_amount = self.base_amount + self.tax_amount
        super().save(*args, **kwargs)
        # update invoice totals
        self.invoice.recompute_totals()
        self.invoice.save(update_fields=["total_base", "total_tax", "total_amount", "updated_at"])


class InvoiceSequence(models.Model):
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE)
    year = models.IntegerField()
    last_number = models.IntegerField(default=0)

    class Meta:
        unique_together = ["tenant", "year"]

    @classmethod
    @transaction.atomic
    def next_number(cls, tenant: Tenant, year: int) -> str:
        obj, _ = cls.objects.select_for_update().get_or_create(tenant=tenant, year=year)
        obj.last_number += 1
        obj.save(update_fields=["last_number"])
        # NNN-OO-UU -> we don't yet have org/subunit codes: stub OO=00 UU=00
        return f"{obj.last_number:03d}-00-00"
